# BolChaal — Flutter

Cross-platform scaffold for the casual English → Roman Urdu translator, with
three swappable engines behind one `TranslationEngine` interface:

- `AiEngine` — calls the Anthropic Messages API
- `PhrasebookEngine` — offline curated phrase lookup, no network
- `GoogleEngine` — Google Cloud Translation, then a local Urdu-script → Roman transliteration pass

## Setup

1. Install the [Flutter SDK](https://docs.flutter.dev/get-started/install) if you haven't.
2. `flutter pub get`
3. Set your API keys — for a quick local test, edit the two blank strings in
   `lib/screens/chat_screen.dart` (`_anthropicApiKey`, `_googleApiKey`). **Don't ship keys
   hardcoded like this** — for a real release, proxy both calls through your own backend.
4. `flutter run` (works on Android, iOS, and desktop targets since there's nothing
   platform-specific in this code yet).

## What's here

```
lib/
  main.dart                    — app entry point
  models/message.dart          — ChatMessage + EngineType
  engines/
    translation_engine.dart    — shared interface
    ai_engine.dart
    phrasebook_engine.dart
    google_engine.dart
  screens/chat_screen.dart     — the whole UI
```

## Known gaps (this is a scaffold, not a finished app)

- No persistent storage yet — wire up `shared_preferences` or `sqflite` to
  persist `_messages` across launches.
- No voice input yet — the `speech_to_text` package is already in `pubspec.yaml`,
  just needs wiring into the composer.
- `PhrasebookEngine`'s dictionary is a starting set (~40 entries) — the web
  prototype has ~90; copy more over as needed.
- The Urdu→Roman transliteration in `GoogleEngine` is a rough character map,
  not linguistically accurate.
- No custom branding/theming beyond a seed color yet.
