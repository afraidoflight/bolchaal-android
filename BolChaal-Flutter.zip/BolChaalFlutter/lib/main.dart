import 'package:flutter/material.dart';
import 'screens/chat_screen.dart';

void main() {
  runApp(const BolChaalApp());
}

class BolChaalApp extends StatelessWidget {
  const BolChaalApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'BolChaal',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFF4A623)),
        useMaterial3: true,
      ),
      home: const ChatScreen(),
    );
  }
}
