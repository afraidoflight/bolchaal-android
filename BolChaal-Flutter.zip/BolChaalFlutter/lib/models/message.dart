class ChatMessage {
  final int id;
  final String english;
  final String urdu;
  final bool approx;
  bool favorite;

  ChatMessage({
    required this.id,
    required this.english,
    required this.urdu,
    this.approx = false,
    this.favorite = false,
  });
}

enum EngineType { ai, phrasebook, google }

extension EngineTypeLabel on EngineType {
  String get label {
    switch (this) {
      case EngineType.ai:
        return 'AI';
      case EngineType.phrasebook:
        return 'Phrasebook';
      case EngineType.google:
        return 'Google';
    }
  }
}
