import 'package:flutter/material.dart';
import '../models/message.dart';
import '../engines/translation_engine.dart';
import '../engines/ai_engine.dart';
import '../engines/phrasebook_engine.dart';
import '../engines/google_engine.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final List<ChatMessage> _messages = [];
  final TextEditingController _controller = TextEditingController();
  EngineType _engineType = EngineType.ai;
  bool _loading = false;
  String? _error;

  // Set these before use — never hardcode real keys in shipped code.
  final String _anthropicApiKey = '';
  final String _googleApiKey = '';

  TranslationEngine get _engine {
    switch (_engineType) {
      case EngineType.ai:
        return AiEngine(_anthropicApiKey);
      case EngineType.phrasebook:
        return PhrasebookEngine();
      case EngineType.google:
        return GoogleEngine(_googleApiKey);
    }
  }

  Future<void> _send() async {
    final text = _controller.text.trim();
    if (text.isEmpty || _loading) return;
    setState(() {
      _loading = true;
      _error = null;
      _controller.clear();
    });
    try {
      final result = await _engine.translate(text);
      setState(() {
        _messages.add(ChatMessage(
          id: DateTime.now().millisecondsSinceEpoch,
          english: text,
          urdu: result.text,
          approx: result.approx,
        ));
      });
    } catch (e) {
      setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      setState(() => _loading = false);
    }
  }

  void _toggleFavorite(int id) {
    setState(() {
      final m = _messages.firstWhere((m) => m.id == id);
      m.favorite = !m.favorite;
    });
  }

  void _remove(int id) {
    setState(() => _messages.removeWhere((m) => m.id == id));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('BolChaal')),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Wrap(
              spacing: 8,
              children: EngineType.values.map((t) {
                return ChoiceChip(
                  label: Text(t.label),
                  selected: _engineType == t,
                  onSelected: (_) => setState(() => _engineType = t),
                );
              }).toList(),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: ListView.builder(
                itemCount: _messages.length,
                itemBuilder: (context, i) {
                  final m = _messages[i];
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 6),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Align(
                          alignment: Alignment.centerRight,
                          child: Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: Colors.amber.shade200,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Text(m.english),
                          ),
                        ),
                        const SizedBox(height: 4),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: Colors.grey.shade200,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(m.urdu),
                                if (m.approx)
                                  const Text('approx. spelling',
                                      style: TextStyle(fontSize: 10, color: Colors.grey)),
                                Row(
                                  children: [
                                    IconButton(
                                      icon: Icon(m.favorite ? Icons.star : Icons.star_border, size: 18),
                                      onPressed: () => _toggleFavorite(m.id),
                                    ),
                                    IconButton(
                                      icon: const Icon(Icons.close, size: 18),
                                      onPressed: () => _remove(m.id),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
            if (_error != null)
              Text(_error!, style: const TextStyle(color: Colors.red, fontSize: 12)),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: const InputDecoration(hintText: 'type something casual...'),
                    onSubmitted: (_) => _send(),
                  ),
                ),
                IconButton(
                  icon: _loading
                      ? const SizedBox(
                          width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.send),
                  onPressed: _loading ? null : _send,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
