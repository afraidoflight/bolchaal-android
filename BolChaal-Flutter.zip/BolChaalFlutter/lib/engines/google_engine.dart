import 'dart:convert';
import 'package:http/http.dart' as http;
import 'translation_engine.dart';

/// Uses Google Cloud Translation to get Urdu (Nastaliq script), then
/// romanizes it locally. The romanization is a rough character-map
/// approximation, not a linguistically accurate transliteration.
class GoogleEngine implements TranslationEngine {
  final String apiKey;
  GoogleEngine(this.apiKey);

  static const Map<String, String> _urduMap = {
    'آ': 'aa', 'ا': 'a', 'ب': 'b', 'پ': 'p', 'ت': 't', 'ٹ': 't', 'ث': 's',
    'ج': 'j', 'چ': 'ch', 'ح': 'h', 'خ': 'kh', 'د': 'd', 'ڈ': 'd', 'ذ': 'z',
    'ر': 'r', 'ڑ': 'r', 'ز': 'z', 'ژ': 'zh', 'س': 's', 'ش': 'sh', 'ص': 's',
    'ض': 'z', 'ط': 't', 'ظ': 'z', 'ع': 'a', 'غ': 'gh', 'ف': 'f', 'ق': 'q',
    'ک': 'k', 'گ': 'g', 'ل': 'l', 'م': 'm', 'ن': 'n', 'ں': 'n', 'و': 'o',
    'ہ': 'h', 'ھ': 'h', 'ء': '', 'ی': 'i', 'ے': 'e', 'ۓ': 'e', 'ؤ': 'o',
    'ئ': 'i', '۔': '.', '،': ',', '؟': '?',
  };

  String _transliterate(String urdu) {
    final buffer = StringBuffer();
    for (final rune in urdu.runes) {
      final ch = String.fromCharCode(rune);
      buffer.write(_urduMap[ch] ?? ch);
    }
    return buffer.toString().replaceAll(RegExp(r'\s+'), ' ').trim();
  }

  @override
  Future<TranslationResult> translate(String englishText) async {
    final res = await http.post(
      Uri.parse('https://translation.googleapis.com/language/translate2?key=$apiKey'),
      headers: {'content-type': 'application/json'},
      body: jsonEncode({'q': englishText, 'target': 'ur', 'format': 'text'}),
    );
    if (res.statusCode != 200) {
      throw Exception('Google request failed (${res.statusCode})');
    }
    final data = jsonDecode(res.body);
    final urduScript = data['data']['translations'][0]['translatedText'] as String;
    return TranslationResult(_transliterate(urduScript), approx: true);
  }
}
