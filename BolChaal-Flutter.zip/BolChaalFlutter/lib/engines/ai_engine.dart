import 'dart:convert';
import 'package:http/http.dart' as http;
import 'translation_engine.dart';

/// Calls the Anthropic Messages API directly.
///
/// Supply your own Anthropic API key. NEVER ship a real key inside a
/// distributed app binary — proxy this through your own backend in
/// production so the key never sits on-device.
class AiEngine implements TranslationEngine {
  final String apiKey;
  AiEngine(this.apiKey);

  @override
  Future<TranslationResult> translate(String englishText) async {
    final prompt =
        "Translate the following English into casual, Latinized (Roman-script) Urdu, "
        "the way friends actually text each other — natural code-switching with English "
        "words where that's realistic, no formal vocabulary. Reply with ONLY the "
        "translation, nothing else, no quotes.\n\nEnglish: $englishText";

    final res = await http.post(
      Uri.parse('https://api.anthropic.com/v1/messages'),
      headers: {
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
        'content-type': 'application/json',
      },
      body: jsonEncode({
        'model': 'claude-sonnet-4-6',
        'max_tokens': 300,
        'messages': [
          {'role': 'user', 'content': prompt}
        ],
      }),
    );

    if (res.statusCode != 200) {
      throw Exception('AI request failed (${res.statusCode})');
    }
    final data = jsonDecode(res.body);
    final block = (data['content'] as List).firstWhere(
      (b) => b['type'] == 'text',
      orElse: () => null,
    );
    if (block == null) throw Exception('No translation returned');
    return TranslationResult((block['text'] as String).trim());
  }
}
