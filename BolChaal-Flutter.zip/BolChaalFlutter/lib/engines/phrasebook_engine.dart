import 'translation_engine.dart';

/// Offline, curated casual-phrase lookup. No network required.
class PhrasebookEngine implements TranslationEngine {
  static const Map<String, String> _phrasebook = {
    'hi': 'hi', 'hello': 'hi bhai', 'hey': 'oye',
    'how are you': 'kya haal hai', 'i am fine': 'mein theek hoon',
    'whats up': 'kya scene hai', 'what are you doing': 'kya kar rahe ho',
    'where are you': 'kahan ho', 'i am coming': 'mein aa raha hoon',
    'come here': 'idhar aao', 'i am busy': 'mein busy hoon',
    'call me': 'call kar dena', 'text me': 'message kar dena',
    "let's go": 'chalo chalte hain', 'i am hungry': 'mujhe bhookh lagi hai',
    'i am tired': 'mein thak gaya hoon', 'good morning': 'subah bakhair',
    'good night': 'shab bakhair', 'thank you': 'shukriya',
    "you're welcome": 'koi baat nahi', 'sorry': 'sorry yaar',
    "it's okay": 'koi baat nahi', 'i love you': 'mein tumse pyar karta hoon',
    'i miss you': 'tumhari yaad aa rahi hai', 'i am happy': 'mein khush hoon',
    'i am sad': 'mein udaas hoon', 'what happened': 'kya hua',
    'are you okay': 'tum theek ho', 'yes': 'haan', 'no': 'nahi',
    'maybe': 'shayad', "i don't know": 'pata nahi',
    'i understand': 'mujhe samajh aa gaya', 'listen to me': 'meri baat suno',
    'give me that': 'woh do mujhe', 'how much is this': 'yeh kitne ka hai',
    "let's meet": 'milte hain', 'see you later': 'phir milte hain',
    'take care': 'apna khayal rakhna', 'hold on': 'ruko zara',
    'congratulations': 'mubarak ho', 'happy birthday': 'janamdin mubarak',
    'stop it': 'bas karo', 'please help me': 'please meri madad karo',
    'this is great': 'yeh bohat acha hai', 'what do you think': 'tumhara kya khayal hai',
    // Extend freely — starting set, not exhaustive.
  };

  String _normalize(String s) =>
      s.trim().toLowerCase().replaceAll(RegExp(r'[.!?]+$'), '');

  @override
  Future<TranslationResult> translate(String englishText) async {
    final key = _normalize(englishText);
    if (_phrasebook.containsKey(key)) {
      return TranslationResult(_phrasebook[key]!);
    }
    final words = key.split(RegExp(r'\s+'));
    if (words.isNotEmpty && words.every((w) => _phrasebook.containsKey(w))) {
      return TranslationResult(
        words.map((w) => _phrasebook[w]).join(' '),
        approx: true,
      );
    }
    throw Exception('Not in the phrasebook yet — try AI mode for this one.');
  }
}
