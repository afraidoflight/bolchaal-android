class TranslationResult {
  final String text;
  final bool approx;
  const TranslationResult(this.text, {this.approx = false});
}

abstract class TranslationEngine {
  /// Throws with a user-facing message string on failure.
  Future<TranslationResult> translate(String englishText);
}
